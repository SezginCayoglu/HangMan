﻿namespace HangMan
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label_Word = new Label();
            label_Header = new Label();
            label_MissedLetters = new Label();
            pn1_draw = new Panel();
            label_FirstLetter = new Label();
            label12_Letter = new Label();
            label11_Letter = new Label();
            label10_Letter = new Label();
            label9_Letter = new Label();
            label8_Letter = new Label();
            label7_Letter = new Label();
            label6_Letter = new Label();
            label5_Letter = new Label();
            label4_Letter = new Label();
            label3_Letter = new Label();
            label2_Letter = new Label();
            label1_Letter = new Label();
            label0_Letter = new Label();
            textBox_test = new TextBox();
            label_WordLength = new Label();
            label_Missed = new Label();
            bt_Start = new Button();
            groupBox2 = new GroupBox();
            textBox_SubmitWord = new TextBox();
            bt_SubmitWord = new Button();
            textBox_SubmitLetter = new TextBox();
            bt_SubmitLetter = new Button();
            groupBox3 = new GroupBox();
            panel_HangMan = new Panel();
            Galgen4 = new DataGridView();
            Galgen3 = new DataGridView();
            Galgen2 = new DataGridView();
            Galgen1 = new DataGridView();
            groupBox1.SuspendLayout();
            pn1_draw.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Galgen4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Galgen3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Galgen2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Galgen1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.CausesValidation = false;
            groupBox1.Controls.Add(label_Word);
            groupBox1.Controls.Add(label_Header);
            groupBox1.Controls.Add(label_MissedLetters);
            groupBox1.Controls.Add(pn1_draw);
            groupBox1.Controls.Add(textBox_test);
            groupBox1.Controls.Add(label_WordLength);
            groupBox1.Controls.Add(label_Missed);
            groupBox1.Location = new Point(14, 16);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(682, 605);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // label_Word
            // 
            label_Word.AutoSize = true;
            label_Word.FlatStyle = FlatStyle.System;
            label_Word.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label_Word.Location = new Point(13, 222);
            label_Word.Margin = new Padding(0);
            label_Word.MaximumSize = new Size(650, 0);
            label_Word.Name = "label_Word";
            label_Word.Padding = new Padding(540, 0, 0, 0);
            label_Word.Size = new Size(540, 54);
            label_Word.TabIndex = 7;
            label_Word.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label_Header
            // 
            label_Header.AutoSize = true;
            label_Header.FlatStyle = FlatStyle.System;
            label_Header.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label_Header.Location = new Point(13, 174);
            label_Header.Margin = new Padding(0);
            label_Header.MaximumSize = new Size(650, 0);
            label_Header.Name = "label_Header";
            label_Header.Padding = new Padding(540, 0, 0, 0);
            label_Header.Size = new Size(540, 38);
            label_Header.TabIndex = 6;
            label_Header.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label_MissedLetters
            // 
            label_MissedLetters.AutoSize = true;
            label_MissedLetters.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label_MissedLetters.Location = new Point(165, 568);
            label_MissedLetters.Name = "label_MissedLetters";
            label_MissedLetters.Size = new Size(0, 28);
            label_MissedLetters.TabIndex = 5;
            // 
            // pn1_draw
            // 
            pn1_draw.Controls.Add(label_FirstLetter);
            pn1_draw.Controls.Add(label12_Letter);
            pn1_draw.Controls.Add(label11_Letter);
            pn1_draw.Controls.Add(label10_Letter);
            pn1_draw.Controls.Add(label9_Letter);
            pn1_draw.Controls.Add(label8_Letter);
            pn1_draw.Controls.Add(label7_Letter);
            pn1_draw.Controls.Add(label6_Letter);
            pn1_draw.Controls.Add(label5_Letter);
            pn1_draw.Controls.Add(label4_Letter);
            pn1_draw.Controls.Add(label3_Letter);
            pn1_draw.Controls.Add(label2_Letter);
            pn1_draw.Controls.Add(label1_Letter);
            pn1_draw.Controls.Add(label0_Letter);
            pn1_draw.Location = new Point(24, 373);
            pn1_draw.Name = "pn1_draw";
            pn1_draw.Size = new Size(651, 119);
            pn1_draw.TabIndex = 3;
            // 
            // label_FirstLetter
            // 
            label_FirstLetter.AutoSize = true;
            label_FirstLetter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label_FirstLetter.Location = new Point(14, 52);
            label_FirstLetter.Name = "label_FirstLetter";
            label_FirstLetter.Size = new Size(0, 38);
            label_FirstLetter.TabIndex = 6;
            label_FirstLetter.Visible = false;
            // 
            // label12_Letter
            // 
            label12_Letter.AutoSize = true;
            label12_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label12_Letter.Location = new Point(614, 52);
            label12_Letter.Name = "label12_Letter";
            label12_Letter.Size = new Size(0, 38);
            label12_Letter.TabIndex = 12;
            // 
            // label11_Letter
            // 
            label11_Letter.AutoSize = true;
            label11_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label11_Letter.Location = new Point(564, 52);
            label11_Letter.Name = "label11_Letter";
            label11_Letter.Size = new Size(0, 38);
            label11_Letter.TabIndex = 11;
            // 
            // label10_Letter
            // 
            label10_Letter.AutoSize = true;
            label10_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label10_Letter.Location = new Point(514, 52);
            label10_Letter.Name = "label10_Letter";
            label10_Letter.Size = new Size(0, 38);
            label10_Letter.TabIndex = 10;
            // 
            // label9_Letter
            // 
            label9_Letter.AutoSize = true;
            label9_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9_Letter.Location = new Point(464, 52);
            label9_Letter.Name = "label9_Letter";
            label9_Letter.Size = new Size(0, 38);
            label9_Letter.TabIndex = 9;
            // 
            // label8_Letter
            // 
            label8_Letter.AutoSize = true;
            label8_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8_Letter.Location = new Point(414, 52);
            label8_Letter.Name = "label8_Letter";
            label8_Letter.Size = new Size(0, 38);
            label8_Letter.TabIndex = 8;
            // 
            // label7_Letter
            // 
            label7_Letter.AutoSize = true;
            label7_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7_Letter.Location = new Point(364, 52);
            label7_Letter.Name = "label7_Letter";
            label7_Letter.Size = new Size(0, 38);
            label7_Letter.TabIndex = 7;
            // 
            // label6_Letter
            // 
            label6_Letter.AutoSize = true;
            label6_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6_Letter.Location = new Point(314, 52);
            label6_Letter.Name = "label6_Letter";
            label6_Letter.Size = new Size(0, 38);
            label6_Letter.TabIndex = 6;
            // 
            // label5_Letter
            // 
            label5_Letter.AutoSize = true;
            label5_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5_Letter.Location = new Point(264, 52);
            label5_Letter.Name = "label5_Letter";
            label5_Letter.Size = new Size(0, 38);
            label5_Letter.TabIndex = 5;
            // 
            // label4_Letter
            // 
            label4_Letter.AutoSize = true;
            label4_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4_Letter.Location = new Point(214, 52);
            label4_Letter.Name = "label4_Letter";
            label4_Letter.Size = new Size(0, 38);
            label4_Letter.TabIndex = 4;
            // 
            // label3_Letter
            // 
            label3_Letter.AutoSize = true;
            label3_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3_Letter.Location = new Point(164, 52);
            label3_Letter.Name = "label3_Letter";
            label3_Letter.Size = new Size(0, 38);
            label3_Letter.TabIndex = 3;
            // 
            // label2_Letter
            // 
            label2_Letter.AutoSize = true;
            label2_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2_Letter.Location = new Point(114, 52);
            label2_Letter.Name = "label2_Letter";
            label2_Letter.Size = new Size(0, 38);
            label2_Letter.TabIndex = 2;
            // 
            // label1_Letter
            // 
            label1_Letter.AutoSize = true;
            label1_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1_Letter.Location = new Point(64, 52);
            label1_Letter.Name = "label1_Letter";
            label1_Letter.Size = new Size(0, 38);
            label1_Letter.TabIndex = 1;
            // 
            // label0_Letter
            // 
            label0_Letter.AutoSize = true;
            label0_Letter.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label0_Letter.Location = new Point(14, 52);
            label0_Letter.Name = "label0_Letter";
            label0_Letter.Size = new Size(0, 38);
            label0_Letter.TabIndex = 0;
            label0_Letter.Visible = false;
            // 
            // textBox_test
            // 
            textBox_test.Location = new Point(131, 28);
            textBox_test.Margin = new Padding(3, 4, 3, 4);
            textBox_test.Multiline = true;
            textBox_test.Name = "textBox_test";
            textBox_test.Size = new Size(449, 65);
            textBox_test.TabIndex = 2;
            textBox_test.Visible = false;
            // 
            // label_WordLength
            // 
            label_WordLength.AutoSize = true;
            label_WordLength.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label_WordLength.Location = new Point(487, 568);
            label_WordLength.Name = "label_WordLength";
            label_WordLength.Size = new Size(135, 28);
            label_WordLength.TabIndex = 1;
            label_WordLength.Text = "Word Length: ";
            // 
            // label_Missed
            // 
            label_Missed.AutoSize = true;
            label_Missed.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label_Missed.Location = new Point(62, 568);
            label_Missed.Name = "label_Missed";
            label_Missed.Size = new Size(82, 28);
            label_Missed.TabIndex = 0;
            label_Missed.Text = "Missed: ";
            // 
            // bt_Start
            // 
            bt_Start.Location = new Point(20, 704);
            bt_Start.Name = "bt_Start";
            bt_Start.Size = new Size(94, 29);
            bt_Start.TabIndex = 4;
            bt_Start.Text = "Start";
            bt_Start.UseVisualStyleBackColor = true;
            bt_Start.Click += bt_Start_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox_SubmitWord);
            groupBox2.Controls.Add(bt_SubmitWord);
            groupBox2.Controls.Add(textBox_SubmitLetter);
            groupBox2.Controls.Add(bt_SubmitLetter);
            groupBox2.Location = new Point(14, 647);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(682, 213);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            // 
            // textBox_SubmitWord
            // 
            textBox_SubmitWord.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_SubmitWord.Location = new Point(455, 68);
            textBox_SubmitWord.Margin = new Padding(3, 4, 3, 4);
            textBox_SubmitWord.Name = "textBox_SubmitWord";
            textBox_SubmitWord.Size = new Size(220, 34);
            textBox_SubmitWord.TabIndex = 3;
            // 
            // bt_SubmitWord
            // 
            bt_SubmitWord.Enabled = false;
            bt_SubmitWord.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            bt_SubmitWord.Location = new Point(285, 64);
            bt_SubmitWord.Margin = new Padding(3, 4, 3, 4);
            bt_SubmitWord.Name = "bt_SubmitWord";
            bt_SubmitWord.Size = new Size(163, 44);
            bt_SubmitWord.TabIndex = 3;
            bt_SubmitWord.Text = "Submit Word";
            bt_SubmitWord.UseVisualStyleBackColor = true;
            bt_SubmitWord.Click += bt_SubmitWord_Click;
            // 
            // textBox_SubmitLetter
            // 
            textBox_SubmitLetter.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_SubmitLetter.Location = new Point(177, 69);
            textBox_SubmitLetter.Margin = new Padding(3, 4, 3, 4);
            textBox_SubmitLetter.MaxLength = 1;
            textBox_SubmitLetter.Name = "textBox_SubmitLetter";
            textBox_SubmitLetter.Size = new Size(70, 34);
            textBox_SubmitLetter.TabIndex = 1;
            // 
            // bt_SubmitLetter
            // 
            bt_SubmitLetter.Enabled = false;
            bt_SubmitLetter.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            bt_SubmitLetter.Location = new Point(7, 65);
            bt_SubmitLetter.Margin = new Padding(3, 4, 3, 4);
            bt_SubmitLetter.Name = "bt_SubmitLetter";
            bt_SubmitLetter.Size = new Size(163, 44);
            bt_SubmitLetter.TabIndex = 0;
            bt_SubmitLetter.Text = "Submit Letter";
            bt_SubmitLetter.UseVisualStyleBackColor = true;
            bt_SubmitLetter.Click += bt_SubmitLetter_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(panel_HangMan);
            groupBox3.Controls.Add(Galgen4);
            groupBox3.Controls.Add(Galgen3);
            groupBox3.Controls.Add(bt_Start);
            groupBox3.Controls.Add(Galgen2);
            groupBox3.Controls.Add(Galgen1);
            groupBox3.Location = new Point(703, 16);
            groupBox3.Margin = new Padding(3, 4, 3, 4);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 4, 3, 4);
            groupBox3.Size = new Size(455, 841);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            // 
            // panel_HangMan
            // 
            panel_HangMan.Location = new Point(126, 202);
            panel_HangMan.Name = "panel_HangMan";
            panel_HangMan.Size = new Size(284, 321);
            panel_HangMan.TabIndex = 5;
            // 
            // Galgen4
            // 
            Galgen4.BackgroundColor = Color.Brown;
            Galgen4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Galgen4.Location = new Point(249, 88);
            Galgen4.Margin = new Padding(3, 4, 3, 4);
            Galgen4.Name = "Galgen4";
            Galgen4.RowHeadersWidth = 51;
            Galgen4.RowTemplate.Height = 25;
            Galgen4.Size = new Size(17, 115);
            Galgen4.TabIndex = 3;
            // 
            // Galgen3
            // 
            Galgen3.BackgroundColor = Color.Red;
            Galgen3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Galgen3.Location = new Point(55, 619);
            Galgen3.Margin = new Padding(3, 4, 3, 4);
            Galgen3.Name = "Galgen3";
            Galgen3.RowHeadersWidth = 51;
            Galgen3.RowTemplate.Height = 25;
            Galgen3.Size = new Size(376, 27);
            Galgen3.TabIndex = 2;
            // 
            // Galgen2
            // 
            Galgen2.BackgroundColor = Color.Black;
            Galgen2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Galgen2.Location = new Point(73, 127);
            Galgen2.Margin = new Padding(3, 4, 3, 4);
            Galgen2.Name = "Galgen2";
            Galgen2.RowHeadersWidth = 51;
            Galgen2.RowTemplate.Height = 25;
            Galgen2.Size = new Size(31, 501);
            Galgen2.TabIndex = 1;
            // 
            // Galgen1
            // 
            Galgen1.BackgroundColor = Color.Black;
            Galgen1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Galgen1.Location = new Point(73, 88);
            Galgen1.Margin = new Padding(3, 4, 3, 4);
            Galgen1.Name = "Galgen1";
            Galgen1.RowHeadersWidth = 51;
            Galgen1.RowTemplate.Height = 25;
            Galgen1.Size = new Size(203, 43);
            Galgen1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1171, 873);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "HangMan - Sezgin Cayoglu";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            pn1_draw.ResumeLayout(false);
            pn1_draw.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Galgen4).EndInit();
            ((System.ComponentModel.ISupportInitialize)Galgen3).EndInit();
            ((System.ComponentModel.ISupportInitialize)Galgen2).EndInit();
            ((System.ComponentModel.ISupportInitialize)Galgen1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label label_WordLength;
        private Label label_Missed;
        private Button bt_SubmitLetter;
        private TextBox textBox_SubmitWord;
        private Button bt_SubmitWord;
        private TextBox textBox_SubmitLetter;
        private DataGridView Galgen1;
        private DataGridView Galgen2;
        private DataGridView Galgen4;
        private DataGridView Galgen3;
        private TextBox textBox_test;
        private Panel pn1_draw;
        private Label label0_Letter;
        private Label label1_Letter;
        private Label label3_Letter;
        private Label label2_Letter;
        private Label label7_Letter;
        private Label label6_Letter;
        private Label label5_Letter;
        private Label label4_Letter;
        private Label label12_Letter;
        private Label label11_Letter;
        private Label label10_Letter;
        private Label label9_Letter;
        private Label label8_Letter;
        private Button bt_Start;
        private Label label_MissedLetters;
        private Panel panel_HangMan;
        private Label label_FirstLetter;
        private Label label_Header;
        private Label label_Word;
    }
}